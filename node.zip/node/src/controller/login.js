const login =  (req,res) => {
    res.status(200).json({status:200, message:'login successfull'});
}
module.exports = {
   login
}