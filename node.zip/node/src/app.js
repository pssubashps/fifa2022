const express = require('express')
const app = express();
const port = 3000;
const apiRoutes = require('./routes');


app.get('/', (req, res) => {
  res.send('Hello World##')
});

app.use('/api', apiRoutes);
app.listen(port, () => {
  console.log(`Example2 app listening on port ${port}`)
});